package trivia;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Font;

public class pregunta {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	
	/**
	 * Create the application.
	 */
	public pregunta() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		
		JLabel lblNewLabel = new JLabel("            Pregunta ");
		lblNewLabel.setToolTipText("center");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
		
		JRadioButton opc1 = new JRadioButton("");
		
		JRadioButton opc2 = new JRadioButton("");
		
		JRadioButton opc3 = new JRadioButton("");
		
		JRadioButton opc4 = new JRadioButton("");
		
		JRadioButton opc5 = new JRadioButton("");
		
		JLabel lblNewLabel_1 = new JLabel("opcion 1");
		
		JLabel lblNewLabel_1_1 = new JLabel("opcion 2");
		
		JLabel lblNewLabel_1_2 = new JLabel("opcion 3");
		
		JLabel lblNewLabel_1_3 = new JLabel("opcion 4");
		
		JLabel lblNewLabel_1_4 = new JLabel("opcion 5");
		
		JButton btnNewButton = new JButton("Salir");
		
		JButton btnNewButton_1 = new JButton("Siguiente >>>");
		
		JLabel lblNewLabel_2 = new JLabel("Trivia");
		lblNewLabel_2.setFont(new Font("Arial Black", Font.BOLD, 16));
		
		JLabel lblNewLabel_3 = new JLabel("               Juega y Ejercita");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 12));
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
					.addGap(70)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 68, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 327, Short.MAX_VALUE)
							.addComponent(lblNewLabel_3)
							.addGap(61))
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(opc1)
									.addGap(18)
									.addComponent(lblNewLabel_1))
								.addGroup(groupLayout.createSequentialGroup()
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(opc4)
									.addGap(18)
									.addComponent(lblNewLabel_1_3))
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(opc5)
									.addGap(18)
									.addComponent(lblNewLabel_1_4))
								.addGroup(groupLayout.createSequentialGroup()
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addComponent(opc2)
										.addComponent(opc3))
									.addGap(18)
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel_1_1)
										.addComponent(lblNewLabel_1_2))))
							.addContainerGap(501, Short.MAX_VALUE))))
				.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
					.addGap(83)
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 164, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(403, Short.MAX_VALUE))
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(btnNewButton_1)
						.addGroup(groupLayout.createSequentialGroup()
							.addContainerGap(575, Short.MAX_VALUE)
							.addComponent(btnNewButton)))
					.addGap(22))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(21)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(lblNewLabel_3))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(opc1)
						.addComponent(lblNewLabel_1))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(opc2)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(opc3))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel_1_1)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(lblNewLabel_1_2)))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_1_3)
						.addComponent(opc4))
					.addGap(10)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(opc5)
						.addComponent(lblNewLabel_1_4))
					.addGap(117)
					.addComponent(btnNewButton_1)
					.addGap(18)
					.addComponent(btnNewButton)
					.addContainerGap(21, Short.MAX_VALUE))
		);
		frame.getContentPane().setLayout(groupLayout);
		frame.setBounds(100, 100, 666, 462);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
